package testcases;

import org.testng.annotations.BeforeTest;

import base.ProjectSpecificMethods;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/main/java/features", glue="pages",monochrome=true)
public class CucumberRunner extends ProjectSpecificMethods{
	
	@BeforeTest
	public void sendTestDetails() {
		testName = "VerifyLogin using Cucumber";
		testDescription = "Verify login for positive data";
		testCategory = "Smoke";
		testAuthor = "Hari";
		
	}

}
