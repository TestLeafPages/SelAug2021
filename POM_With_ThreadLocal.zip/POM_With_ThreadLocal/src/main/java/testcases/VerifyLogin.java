package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class VerifyLogin extends ProjectSpecificMethods {
	
	@BeforeTest
	public void sendTestDetails() {
		testName = "VerifyLogin";
		testDescription = "Verify login for positive data";
		testCategory = "Smoke";
		testAuthor = "Hari";
		fileName = "Login";

	}
	
	@Test(dataProvider = "sendData")
	public void login(String username, String password) throws InterruptedException, IOException {
		
		new LoginPage()
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.verifyHomePage();
		

	}

}
