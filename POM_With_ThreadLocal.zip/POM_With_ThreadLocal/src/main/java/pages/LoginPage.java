package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethods {
	
		
	@Given("Enter the username as {string}")
	public LoginPage enterUsername(String username) throws InterruptedException, IOException {
		
		getDriver().findElement(By.id("username")).sendKeys(username);
			
		return this;
	}

	@Given("Enter the Password as {string}")
	public LoginPage enterPassword(String password) throws IOException {
		getDriver().findElement(By.id("password")).sendKeys(password);
			
		return this;
	}
	
	
	@When("Click on the Login")
	public HomePage clickLoginButton() throws IOException {
		
		getDriver().findElement(By.className("decorativeSubmit")).click();
		
		return new HomePage();

	}
	
	
	public LoginPage clickLoginButtonForNegative() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return this;

	}
	
	

}
