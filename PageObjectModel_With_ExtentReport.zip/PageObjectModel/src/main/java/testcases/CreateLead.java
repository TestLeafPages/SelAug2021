package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethods {
	
	@BeforeTest
	public void sendTestDetails() {
		testName = "CreateLead";
		testDescription = "Create lead with mandatory informations";
		testCategory = "Functional";
		testAuthor = "Hari";
		fileName = "CreateLead";

	}
	
	@Test(dataProvider = "sendData")
	public void runCreateLead(String username,String password,String fName, String lName, String company) throws InterruptedException, IOException {
		
		new LoginPage(driver)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCrmSFA()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterFirstName(fName)
		.enterLastName(lName)
		.enterCompanyName(company)
		.clickCreateLeadButton()
		.verifyFirstName();
		

	}

}
