package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
		
	}
	
	// action+elementName
	public LoginPage enterUsername(String username) throws InterruptedException, IOException {
		try {
			driver.findElement(By.id("username")).sendKeys(username);
			reportStep(username+" username entered successfully", "pass");
		} catch (Exception e) {
			reportStep("username not entered successfully", "fail");
		}
		return this;
	}

	public LoginPage enterPassword(String password) throws IOException {
		try {
			driver.findElement(By.id("password")).sendKeys(password);
			reportStep(password+" password entered successfully", "pass");
		} catch (Exception e) {
			reportStep("password not entered successfully", "fail");
		}
		return this;
	}
	
	
	public HomePage clickLoginButton() throws IOException {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			reportStep("Login button is clicked successfully", "pass");
		} catch (Exception e) {
			reportStep("Login button is not clicked successfully", "fail");
		}
		return new HomePage(driver);

	}
	
	
	public LoginPage clickLoginButtonForNegative() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return this;

	}
	
	

}
