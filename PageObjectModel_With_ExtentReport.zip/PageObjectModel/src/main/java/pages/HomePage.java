package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {

	public HomePage(ChromeDriver driver) {
		this.driver = driver;

	}

	public LoginPage clickLogoutButton() {
		driver.findElement(By.className("decorativeSubmit")).click();

		return new LoginPage(driver);
	}

	public HomePage verifyHomePage() throws IOException {
		try {
			WebElement ele = driver.findElement(By.linkText("CRM/SFA"));
			boolean displayed = driver.findElement(By.linkText("CRM/SFA")).isDisplayed();
			if(displayed) {
				reportStep("CRMSFA link is displayed", "pass");
			}else {
				reportStep("CRMSFA link is not displayed", "fail");
			}
			
			reportStep("Homepage is displayed", "pass");
		} catch (Exception e) {
			reportStep("Homepage is not displayed", "fail");
		}
		
		
		
		return this;
	}

	public MyHomePage clickCrmSFA() {
		driver.findElement(By.linkText("CRM/SFA")).click();

		return new MyHomePage(driver);

	}

}
